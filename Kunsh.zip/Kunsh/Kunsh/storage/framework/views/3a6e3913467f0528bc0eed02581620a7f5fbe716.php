<?php $__env->startSection('content'); ?>
<div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header"> Document  </div>

                    <div class="card-body">

                    	<form method="POST" action="/Kunsh/Kunsh/public/admin/document">
                    		<?php echo e(csrf_field()); ?>

                    		<div class="form-group row">
                            <label for="email" class="col-md-4 col-form-label text-md-right">Document Name</label>

                            <div class="col-md-6">
                                <input id="name" type="text" class="form-control" name="name" required>

                                <?php if($errors->has('name')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('name')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <input type="hidden" name="user_id" value="<?php echo e($user_id); ?>">

                        <div class="form-group row">
                            <label for="email" class="col-md-4 col-form-label text-md-right">Document URL</label>

                            <div class="col-md-6">
                                <input id="name" type="text" class="form-control" name="url" required>

                                <?php if($errors->has('name')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('name')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="email" class="col-md-4 col-form-label text-md-right">Document Type</label>

                            <div class="col-md-6">
                               <input type="text" name="documentType">

                                <?php if($errors->has('name')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('name')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                         <div class="form-group row mb-0">
                            <div class="col-md-6 offset-md-4">
                                <button type="submit" class="btn btn-primary">
                                    Submit
                                </button>
                            </div>
                        </div>

                    	</form>
                </div>
            </div>
        </div>
</div>
<div class="mycontainer" style="margin-top: 10px;">
    <table class="table table-bordered table-striped dt-select">
        <tr>
            <th>ID</th>
            <th>Name</th>
            <th>URL</th>
            <th>Type</th>
        </tr>
        <?php $__currentLoopData = $documents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $document): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($loop->iteration); ?></td>
                <td><?php echo e($document->document_name); ?></td>
                <td><?php echo e($document->document_url); ?></td>
                <td><?php echo e($document->document_type); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>