<?php $__env->startSection('content'); ?>
<div class="container">
    <?php if($get_role[0]->role == 'admin'): ?>
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header"> User 
                        <a href="/Kunsh/Kunsh/public/admin/adduser" style="margin-left: 560px;"><button type="button" class="btn btn-default">Add User</button></a>
                    </div>

                    <div class="card-body">
                        <table class="table table-bordered table-striped dt-select">
                            <tr>
                                <th>ID</th>
                                <th>Name</th>
                                <th>Email</th>
                                <th>User Detail</th>
                                <th>Update User</th>
                                <th>Document Upload</th>
                                <th>Delete User</th>
                            </tr>
                            <?php $__currentLoopData = $get_user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($loop->iteration); ?></td>
                                    <td><?php echo e($user->name); ?></td>
                                    <td><?php echo e($user->email); ?></td>
                                    <td><a href="/Kunsh/Kunsh/public/admin/edit/<?php echo e($user->id); ?>"><button type="button" class="btn btn-default">Detail</button></a></td>
                                    <td><a href="/Kunsh/Kunsh/public/admin/update/<?php echo e($user->id); ?>"><button type="button" class="btn btn-default">Update</button></a></td>
                                    <td><a href="/Kunsh/Kunsh/public/admin/document/<?php echo e($user->id); ?>"><button type="button" class="btn btn-default"> Document</button></a></td>
                                    <td><a href="/Kunsh/Kunsh/public/admin/delete/<?php echo e($user->id); ?>"><button type="button" class="btn btn-default"> Delete </button></a></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                       </table>
                    </div>
                </div>
            </div>
        </div>
    <?php else: ?>
        Welcome USER
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>