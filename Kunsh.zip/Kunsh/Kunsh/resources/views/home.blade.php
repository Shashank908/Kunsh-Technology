@extends('layouts.app')

@section('content')
<div class="container">
    @if($get_role[0]->role == 'admin')
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header"> User 
                        <a href="/Kunsh/Kunsh/public/admin/adduser" style="margin-left: 560px;"><button type="button" class="btn btn-default">Add User</button></a>
                    </div>

                    <div class="card-body">
                        <table class="table table-bordered table-striped dt-select">
                            <tr>
                                <th>ID</th>
                                <th>Name</th>
                                <th>Email</th>
                                <th>User Detail</th>
                                <th>Update User</th>
                                <th>Document Upload</th>
                                <th>Delete User</th>
                            </tr>
                            @foreach($get_user as $user)
                                <tr>
                                    <td>{{$loop->iteration}}</td>
                                    <td>{{$user->name}}</td>
                                    <td>{{$user->email}}</td>
                                    <td><a href="/Kunsh/Kunsh/public/admin/edit/{{$user->id}}"><button type="button" class="btn btn-default">Detail</button></a></td>
                                    <td><a href="/Kunsh/Kunsh/public/admin/update/{{$user->id}}"><button type="button" class="btn btn-default">Update</button></a></td>
                                    <td><a href="/Kunsh/Kunsh/public/admin/document/{{$user->id}}"><button type="button" class="btn btn-default"> Document</button></a></td>
                                    <td><a href="/Kunsh/Kunsh/public/admin/delete/{{$user->id}}"><button type="button" class="btn btn-default"> Delete </button></a></td>
                                </tr>
                            @endforeach
                       </table>
                    </div>
                </div>
            </div>
        </div>
    @else
        Welcome USER
    @endif
</div>
@endsection
