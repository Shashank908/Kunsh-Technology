@extends('layouts.app')

@section('content')
<div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header"> Document  </div>

                    <div class="card-body">

                    	<form method="POST" action="/Kunsh/Kunsh/public/admin/document">
                    		{{ csrf_field()}}
                    		<div class="form-group row">
                            <label for="email" class="col-md-4 col-form-label text-md-right">Document Name</label>

                            <div class="col-md-6">
                                <input id="name" type="text" class="form-control" name="name" required>

                                @if ($errors->has('name'))
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('name') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>
                        <input type="hidden" name="user_id" value="{{$user_id}}">

                        <div class="form-group row">
                            <label for="email" class="col-md-4 col-form-label text-md-right">Document URL</label>

                            <div class="col-md-6">
                                <input id="name" type="text" class="form-control" name="url" required>

                                @if ($errors->has('name'))
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('name') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="email" class="col-md-4 col-form-label text-md-right">Document Type</label>

                            <div class="col-md-6">
                               <input type="text" name="documentType">

                                @if ($errors->has('name'))
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('name') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>

                         <div class="form-group row mb-0">
                            <div class="col-md-6 offset-md-4">
                                <button type="submit" class="btn btn-primary">
                                    Submit
                                </button>
                            </div>
                        </div>

                    	</form>
                </div>
            </div>
        </div>
</div>
<div class="mycontainer" style="margin-top: 10px;">
    <table class="table table-bordered table-striped dt-select">
        <tr>
            <th>ID</th>
            <th>Name</th>
            <th>URL</th>
            <th>Type</th>
        </tr>
        @foreach($documents as $document)
            <tr>
                <td>{{$loop->iteration}}</td>
                <td>{{$document->document_name}}</td>
                <td>{{$document->document_url}}</td>
                <td>{{$document->document_type}}</td>
            </tr>
        @endforeach
    </table>
</div>
@endsection