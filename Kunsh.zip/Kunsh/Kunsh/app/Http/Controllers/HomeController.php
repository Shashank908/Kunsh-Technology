<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Auth;
use DB;
use App\User;
use Carbon\Carbon;

class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $get_id = Auth::guard()->user()->id;
        $get_role = DB::table('users')->select('role')->where('id', $get_id)->get()->toArray();
        $get_user = User::all();
        //dd($get_role);
        return view('home', compact('get_role','get_user'));
    }

    public function delete1($id)
    {
        //dd($id);
        DB::table('users')->where('id', $id)->delete();
        return redirect('/home');
    }

    public function edit($id)
    {
        $user = DB::table('users')->where('id', $id)->get()->toArray();
        //dd($user);
        return view('edit', compact('user'));
    }

    public function store(Request $request, $id)
    {
        //dd($id);
        $values = array('user_id' => $id, 'organisation_key' => request('name'), 'org_name' => request('key'), 'description' => request('description'), 'approval' => request('approval'), 'phone' => request('phone'), 'website' => request('website'), 'address' => request('address'));
        //dd($values);
        DB::table('user_details')->insert($values);
        return redirect('/home');
    }
    public function document($id)
    {
        $user_id = Auth::guard()->user()->id;
        //dd($user_id);
        $user_id = Auth::guard()->user()->id;
        $documents = DB::table('legal__documents')->where('user_id',$user_id)->get()->toArray();
        return view('document', compact('user_id','documents'));
    }

    public function documentStore(Request $request)
    {
        $values = array('user_id' => request('user_id'), 'document_name' => request('name'), 'document_url' => request('url'), 'document_type' => request('documentType'), 'created_at' => Carbon::now(), 'updated_at' => Carbon::now());
        //dd($values);
        DB::table('legal__documents')->insert($values);
        $user_id = Auth::guard()->user()->id;
        $documents = DB::table('legal__documents')->where('user_id',$user_id)->get()->toArray();
        return view('document', compact('documents','user_id'));
    }

    public function update($id)
    {
        $user_data = DB::table('users')->where('id', $id)->get()->toArray();
        return view('update', compact('user_data'));
    }

    public function update1(Request $request)
    {
        $values = array('name' => request('name'), 'email' => request('email'), 'password' => bcrypt(request('password')), 'role' => request('role'));
        //dd(request('user_id'));
        DB::table('users')->where('id', request('user_id'))->update($values);
        return redirect('/home');
    }
    public function adduser()
    {
        return view('adduser');
    }
    public function registeruser(Request $request)
    {
        $validatedData = $request->validate([
            'name' => 'required|max:100',
            'email' => 'required|max:255|unique:users',
            'password' => 'required|string|min:6|confirmed',
            'role' => 'required',
        ]);

        $values = array('name' => request('name'), 'email' => request('email'), 'password' => request('password'), 'role' => request('role'));
        DB::table('users')->insert($values);
        return redirect('/home');
    }
}
