<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class User_detail extends Model
{
    protected $fillable = [
    	'user_id', 'organisation_key', 'org_name', 'description', 'approval', 'phone', 'website',
        'address', 
    ];
}
