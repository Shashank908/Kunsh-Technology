<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('auth.login');
});

Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');

Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');

// For Complete deletion.
Route::get('/admin/delete/{id}', 'HomeController@delete1');
Route::get('/admin/edit/{id}', 'HomeController@edit');
Route::post('/admin/edit/{id}', 'HomeController@store');
Route::get('/admin/document/{id}', 'HomeController@document');
Route::post('/admin/document', 'HomeController@documentStore');
Route::get('/admin/update/{id}', 'HomeController@update');
Route::post('/admin/update', 'HomeController@update1');
Route::get('/admin/adduser', 'HomeController@adduser');
Route::post('/admin/registeruser', 'HomeController@registeruser');
